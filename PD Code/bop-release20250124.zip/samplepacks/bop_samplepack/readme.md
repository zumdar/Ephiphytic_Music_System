# bop_samplepack

An open source samplepack distributed with [bop](http://github.com/zealtv/bop) for Pure Data.

## Contributors

Some samples from [Ian McCurdy](http://www.iainmccurdy.org/soundlibrary.html) under [Creative Commons license Attribution 2.0](https://creativecommons.org/licenses/by/2.0/).